# api/index.py | Flask on Vercel Python runtime
# Vercel gotcha: no persistent filesystem — results returned as JSON only
# Vercel gotcha: max execution 10s (hobby) / 60s (pro) — keep batch small

from __future__ import annotations

import json
import os
import random
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Optional

# ── Lazy imports (Vercel installs from requirements.txt) ──────────────────────
try:
    import requests
    import urllib3
    from Crypto.Cipher import AES
    from Crypto.Util.Padding import pad
    import blackboxprotobuf
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
    _DEPS_OK = True
except ImportError as _e:
    _DEPS_OK = False
    _DEPS_ERR = str(_e)

from flask import Flask, Response, jsonify, render_template_string, request

app = Flask(__name__)

# ── Config ────────────────────────────────────────────────────────────────────
APP_ID        = 100067
CLIENT_SECRET = "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3"
AES_KEY       = bytes([89,103,38,116,99,37,68,69,117,104,54,37,90,99,94,56])
AES_IV        = bytes([54,111,121,90,68,114,50,50,69,51,121,99,104,106,77,37])
RELEASE_VER   = "OB55"
REGION        = "ID"   # Indonesia — hardcoded

URL_TOKEN_GRANT = "https://100067.connect.garena.com/api/v2/oauth/guest/token:grant"
URL_MAJOR_LOGIN = "https://loginbp.ppmainecoonghj.com/MajorLogin"

INDIAN_IPS = [
    "49.36.180.10","49.36.181.15","103.87.24.10",
    "115.99.10.20","49.36.83.10","103.25.12.10",
]

UAS = [
    "UnityPlayer/2022.3.47f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
    "UnityPlayer/2019.4.12f1 (UnityWebRequest/1.0, libcurl/7.75.0-DEV)",
    "GarenaMSDK/4.0.19P9",
]

NICK_ADJECTIVES = ["Dark","Shadow","Ghost","Blade","Storm","Iron","Swift","Void","Nova","Apex"]
NICK_NOUNS      = ["Wolf","Dragon","Viper","Eagle","Tiger","Shark","Hawk","Bear","Fox","Lion"]

# ── Rarity classifier ─────────────────────────────────────────────────────────
def classify_rarity(account_id) -> dict:
    uid = str(account_id).strip()
    if not uid.isdigit() or not uid:
        return {"tier": "COMMON", "label": "· Common", "color": "#6b7280"}

    n    = len(uid)
    nums = [int(d) for d in uid]

    # LEGENDARY: all same OR perfect seq
    if len(set(uid)) == 1:
        return {"tier": "LEGENDARY", "label": "✦ Legendary", "color": "#f59e0b"}
    diffs = [nums[i+1]-nums[i] for i in range(len(nums)-1)]
    if all(d==1 for d in diffs) or all(d==-1 for d in diffs):
        return {"tier": "LEGENDARY", "label": "✦ Legendary", "color": "#f59e0b"}

    # EPIC: palindrome / 000|999 ends / short UID
    if uid == uid[::-1] and n >= 5:
        return {"tier": "EPIC", "label": "◆ Epic", "color": "#a855f7"}
    if uid[:3] in ("000","999") or uid[-3:] in ("000","999"):
        return {"tier": "EPIC", "label": "◆ Epic", "color": "#a855f7"}
    if n <= 8:
        return {"tier": "EPIC", "label": "◆ Epic", "color": "#a855f7"}

    # RARE: 9-digit or 4+ consecutive same
    if n == 9:
        return {"tier": "RARE", "label": "★ Rare", "color": "#06b6d4"}
    run = cur = 1
    for i in range(1, n):
        cur = cur+1 if uid[i]==uid[i-1] else 1
        run = max(run, cur)
    if run >= 4:
        return {"tier": "RARE", "label": "★ Rare", "color": "#06b6d4"}

    # UNCOMMON: 10-digit
    if n == 10:
        return {"tier": "UNCOMMON", "label": "◇ Uncommon", "color": "#22c55e"}

    return {"tier": "COMMON", "label": "· Common", "color": "#6b7280"}

# ── Crypto ────────────────────────────────────────────────────────────────────
def aes_encrypt(hex_payload: str) -> str:
    raw    = bytes.fromhex(hex_payload)
    cipher = AES.new(AES_KEY, AES.MODE_CBC, AES_IV)
    return cipher.encrypt(pad(raw, AES.block_size)).hex()

# ── Protobuf builder ──────────────────────────────────────────────────────────
def _varint(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F; n >>= 7
        if n: b |= 0x80
        out.append(b)
        if not n: break
    return bytes(out)

def _field(fn: int, v) -> bytes:
    if isinstance(v, int):
        return _varint((fn<<3)|0) + _varint(v)
    raw = v.encode() if isinstance(v, str) else v
    return _varint((fn<<3)|2) + _varint(len(raw)) + raw

def proto_build(fields: dict) -> bytes:
    return b"".join(_field(k,v) for k,v in fields.items())

def proto_encrypt(fields: dict) -> bytes:
    p = proto_build(fields)
    try:    return bytes.fromhex(aes_encrypt(p.hex()))
    except: return p

# ── Device / nickname ─────────────────────────────────────────────────────────
def random_device() -> dict:
    models  = ["Xiaomi Redmi Note 8","Samsung Galaxy A52","Realme 8","OPPO A54","Vivo Y21"]
    gpus    = ["Adreno (TM) 505","Mali-G57 MC2","Adreno (TM) 610","PowerVR GT7600"]
    return {
        "model":     random.choice(models),
        "gpu":       random.choice(gpus),
        "os_string": f"Android OS {random.choice([9,10,11,12])} / API-{random.choice([28,29,30,31])}",
        "ip":        random.choice(INDIAN_IPS),
        "device_id": f"Google|{uuid.uuid4()}",
    }

def random_nick(prefix: str = "ANGEL") -> str:
    adj  = random.choice(NICK_ADJECTIVES)
    noun = random.choice(NICK_NOUNS)
    num  = random.randint(10, 999)
    return f"{prefix}{adj}{noun}{num}"[:20]

# ── JWT extractor ─────────────────────────────────────────────────────────────
JWT_RE = re.compile(r"eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+")

def extract_jwt(body: bytes) -> Optional[str]:
    for offset in (0, 4, 8, 16, 64):
        try:
            dec, _ = blackboxprotobuf.decode_message(body[offset:] if offset < len(body) else body)
            if isinstance(dec, dict):
                for k in ("8", 8, "jwt", "token"):
                    v = dec.get(k)
                    if isinstance(v, bytes): v = v.decode("utf-8","ignore")
                    if isinstance(v, str) and v.startswith("eyJ"): return v
        except: continue
    m = JWT_RE.search(body.decode("utf-8","ignore"))
    return m.group(0) if m else None

def is_valid_jwt(t) -> bool:
    return bool(t) and isinstance(t,str) and t.startswith("eyJ") and t.count(".")>=2 and len(t)>=50

# ── Token grant ───────────────────────────────────────────────────────────────
def token_grant(uid: str, password: str) -> Optional[dict]:
    try:
        body = json.dumps({
            "client_id":     APP_ID,
            "client_secret": CLIENT_SECRET,
            "client_type":   2,
            "device_id":     f"02-{uuid.uuid4()}",
            "password":      password,
            "response_type": "token",
            "uid":           int(uid),
        }, separators=(",",":"))
        r = requests.post(
            URL_TOKEN_GRANT,
            headers={"User-Agent": random.choice(UAS),
                     "Content-Type": "application/json; charset=utf-8",
                     "Accept": "application/json"},
            data=body, timeout=10, verify=False,
        )
        if r.status_code != 200: return None
        d  = r.json().get("data", r.json())
        at = d.get("access_token")
        oi = d.get("open_id")
        return {"access_token": str(at), "open_id": str(oi)} if at and oi else None
    except: return None

# ── Major login ───────────────────────────────────────────────────────────────
def major_login(open_id: str, access_token: str) -> Optional[str]:
    try:
        dev = random_device()
        ts  = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        payload = proto_encrypt({
            3: ts, 4: "free fire", 5: 4,
            7: "1.132.1", 8: "2019116753",
            9: dev["os_string"], 10: "Handheld", 11: dev["model"],
            12: 1280, 13: 720, 14: "240",
            15: "x86-64 SSE3 SSE4.1 SSE4.2 AVX | 2400 | 4",
            16: random.choice([5951,6100,5500,6500]),
            17: dev["gpu"], 18: "OpenGL ES 3.1 v1.46",
            19: dev["device_id"], 20: dev["ip"],
            21: "id", 22: open_id, 23: "4",
            24: "Handheld", 25: dev["model"],
            26: "ID", 29: access_token, 30: 1,
            41: "Telkomsel", 42: "WIFI",
            92: random.choice([19788,20000,21000]),
            93: "android_max", 97: 1, 98: 1,
        })
        headers = {
            "User-Agent":      random.choice(UAS),
            "Accept-Encoding": "deflate, gzip",
            "Content-Type":    "application/octet-stream",
            "Authorization":   f"Bearer {access_token}",
            "X-GA":            "v1 1",
            "ReleaseVersion":  RELEASE_VER,
        }
        r = requests.post(URL_MAJOR_LOGIN, headers=headers, data=payload, timeout=10, verify=False)
        if r.status_code != 200 or len(r.content) < 20: return None
        jwt = extract_jwt(r.content)
        return jwt if is_valid_jwt(jwt) else None
    except: return None

# ── Get account_id from JWT payload ──────────────────────────────────────────
def extract_account_id(jwt_token: str) -> str:
    try:
        import base64
        payload = jwt_token.split(".")[1]
        payload += "=" * (4 - len(payload) % 4)
        data = json.loads(base64.b64decode(payload).decode("utf-8","ignore"))
        for k in ("account_id","accountId","sub","uid","id"):
            if k in data: return str(data[k])
    except: pass
    return ""

# ── Generate one guest account ────────────────────────────────────────────────
def generate_one(prefix: str = "ANGEL") -> dict:
    if not _DEPS_OK:
        return {"error": f"Missing deps: {_DEPS_ERR}"}

    uid      = str(random.randint(10**9, 10**12))
    password = f"DARK{''.join(random.choices('ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789', k=10))}"
    nick     = random_nick(prefix)

    # TokenGrant
    grant = token_grant(uid, password)
    if not grant:
        return {"error": "token_grant failed", "uid": uid}

    # MajorLogin → JWT
    jwt = major_login(grant["open_id"], grant["access_token"])
    if not jwt:
        return {"error": "major_login failed", "uid": uid}

    account_id = extract_account_id(jwt)
    rarity     = classify_rarity(account_id)

    return {
        "uid":        uid,
        "password":   password,
        "account_id": account_id,
        "name":       nick,
        "region":     REGION,
        "rarity":     rarity["tier"],
        "rarity_label": rarity["label"],
        "rarity_color": rarity["color"],
        "open_id":    grant["open_id"],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "status":     "generated",
    }

# ── HTML frontend ─────────────────────────────────────────────────────────────
HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>FF Guest Generator — Indonesia</title>
<style>
  :root {
    --bg: #0a0a0f; --surface: #13131a; --border: #1e1e2e;
    --gold: #f59e0b; --cyan: #06b6d4; --green: #22c55e;
    --red: #ef4444; --purple: #a855f7; --steel: #6b7280;
    --text: #e2e8f0; --muted: #94a3b8;
    --legendary: #f59e0b; --epic: #a855f7;
    --rare: #06b6d4; --uncommon: #22c55e; --common: #6b7280;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: var(--bg); color: var(--text);
    font-family: 'Courier New', monospace;
    min-height: 100vh; padding: 24px 16px;
  }
  .header {
    text-align: center; margin-bottom: 32px;
  }
  .header h1 {
    font-size: clamp(1.4rem, 4vw, 2rem);
    color: var(--gold); letter-spacing: 2px; margin-bottom: 4px;
  }
  .header p { color: var(--muted); font-size: 0.85rem; }
  .server-badge {
    display: inline-block; margin-top: 8px;
    background: rgba(239,68,68,0.15); border: 1px solid var(--red);
    color: var(--red); padding: 2px 12px; border-radius: 4px;
    font-size: 0.8rem; letter-spacing: 1px;
  }
  .controls {
    max-width: 480px; margin: 0 auto 32px;
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 8px; padding: 20px;
  }
  .controls label {
    display: block; color: var(--muted); font-size: 0.8rem;
    margin-bottom: 6px; letter-spacing: 1px;
  }
  .controls input {
    width: 100%; background: var(--bg); border: 1px solid var(--border);
    color: var(--text); padding: 8px 12px; border-radius: 4px;
    font-family: inherit; font-size: 0.9rem; margin-bottom: 16px;
    outline: none;
  }
  .controls input:focus { border-color: var(--gold); }
  .row { display: flex; gap: 12px; }
  .row > * { flex: 1; }
  .btn {
    width: 100%; padding: 12px;
    background: linear-gradient(135deg, #b45309, #f59e0b);
    color: #000; border: none; border-radius: 6px;
    font-family: inherit; font-size: 0.95rem; font-weight: bold;
    cursor: pointer; letter-spacing: 1px; transition: opacity 0.2s;
  }
  .btn:hover { opacity: 0.85; }
  .btn:disabled { opacity: 0.4; cursor: not-allowed; }
  .btn-dl {
    background: linear-gradient(135deg, #0e7490, #06b6d4);
    margin-top: 12px;
  }
  .status {
    text-align: center; margin-bottom: 24px;
    font-size: 0.85rem; color: var(--muted); min-height: 20px;
  }
  .status.err  { color: var(--red); }
  .status.ok   { color: var(--green); }
  .cards { max-width: 600px; margin: 0 auto; display: flex; flex-direction: column; gap: 12px; }
  .card {
    background: var(--surface); border-radius: 8px;
    border: 1px solid var(--border); overflow: hidden;
    animation: fadeIn 0.3s ease;
  }
  @keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
  .card-header {
    padding: 10px 14px;
    display: flex; align-items: center; justify-content: space-between;
    border-bottom: 1px solid var(--border);
  }
  .card-header .slot { color: var(--muted); font-size: 0.75rem; }
  .rarity-badge {
    font-size: 0.75rem; font-weight: bold; letter-spacing: 1px;
    padding: 2px 10px; border-radius: 4px;
    background: rgba(255,255,255,0.05);
  }
  .card-body { padding: 12px 14px; }
  .kv { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 0.82rem; }
  .kv .k { color: var(--muted); }
  .kv .v { color: var(--text); font-weight: bold; word-break: break-all; text-align: right; max-width: 65%; }
  .card.LEGENDARY { border-color: var(--legendary); }
  .card.EPIC      { border-color: var(--epic); }
  .card.RARE      { border-color: var(--rare); }
  .card.UNCOMMON  { border-color: var(--uncommon); }
  .card.COMMON    { border-color: var(--border); }
  .err-card {
    background: rgba(239,68,68,0.08); border: 1px solid var(--red);
    border-radius: 8px; padding: 12px 14px; font-size: 0.82rem;
    color: var(--red); animation: fadeIn 0.3s ease;
  }
  .spinner {
    display: inline-block; width: 14px; height: 14px;
    border: 2px solid #333; border-top-color: var(--gold);
    border-radius: 50%; animation: spin 0.7s linear infinite;
    vertical-align: middle; margin-right: 8px;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
  .stats-bar {
    max-width: 600px; margin: 0 auto 20px;
    display: flex; gap: 12px; flex-wrap: wrap;
  }
  .stat {
    flex: 1; min-width: 80px;
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 6px; padding: 8px 12px; text-align: center;
  }
  .stat .n  { font-size: 1.3rem; font-weight: bold; }
  .stat .lbl{ font-size: 0.7rem; color: var(--muted); letter-spacing: 1px; }
</style>
</head>
<body>
<div class="header">
  <h1>⚡ FF GUEST GENERATOR</h1>
  <p>Generate Free Fire guest accounts</p>
  <div class="server-badge">🇮🇩 SERVER INDONESIA</div>
</div>

<div class="controls">
  <label>NICK PREFIX</label>
  <input id="prefix" value="ANGEL" maxlength="10" placeholder="ANGEL">
  <div class="row">
    <div>
      <label>JUMLAH AKUN</label>
      <input id="count" type="number" value="5" min="1" max="20" placeholder="5">
    </div>
  </div>
  <button class="btn" id="genBtn" onclick="generate()">⚡ GENERATE</button>
  <button class="btn btn-dl" id="dlBtn" onclick="downloadJSON()" style="display:none">📥 DOWNLOAD JSON</button>
</div>

<div class="status" id="status"></div>

<div class="stats-bar" id="statsBar" style="display:none">
  <div class="stat"><div class="n" id="sTotal" style="color:var(--gold)">0</div><div class="lbl">TOTAL</div></div>
  <div class="stat"><div class="n" id="sOk"    style="color:var(--green)">0</div><div class="lbl">SUCCESS</div></div>
  <div class="stat"><div class="n" id="sErr"   style="color:var(--red)">0</div><div class="lbl">FAILED</div></div>
  <div class="stat"><div class="n" id="sRare"  style="color:var(--cyan)">0</div><div class="lbl">RARE+</div></div>
</div>

<div class="cards" id="cards"></div>

<script>
let allAccounts = [];
let stats = { total:0, ok:0, err:0, rare:0 };

function setStatus(msg, cls='') {
  const el = document.getElementById('status');
  el.innerHTML = msg; el.className = 'status ' + cls;
}

function updateStats() {
  document.getElementById('statsBar').style.display = 'flex';
  document.getElementById('sTotal').textContent = stats.total;
  document.getElementById('sOk').textContent    = stats.ok;
  document.getElementById('sErr').textContent   = stats.err;
  document.getElementById('sRare').textContent  = stats.rare;
}

function addCard(acc, idx) {
  const cards = document.getElementById('cards');
  if (acc.error) {
    const d = document.createElement('div');
    d.className = 'err-card';
    d.innerHTML = `<strong>#${idx} FAILED</strong> — ${acc.error}`;
    cards.prepend(d); return;
  }
  const d = document.createElement('div');
  d.className = `card ${acc.rarity}`;
  const hdrColor = acc.rarity_color || '#6b7280';
  d.innerHTML = `
    <div class="card-header">
      <span class="slot">#${idx}</span>
      <span class="rarity-badge" style="color:${hdrColor};border-color:${hdrColor}">${acc.rarity_label}</span>
    </div>
    <div class="card-body">
      <div class="kv"><span class="k">Nickname</span><span class="v" style="color:var(--green)">${acc.name}</span></div>
      <div class="kv"><span class="k">Account ID</span><span class="v" style="color:${hdrColor}">${acc.account_id || '-'}</span></div>
      <div class="kv"><span class="k">Login UID</span><span class="v" style="color:var(--cyan)">${acc.uid}</span></div>
      <div class="kv"><span class="k">Password</span><span class="v" style="color:#93c5fd">${acc.password}</span></div>
      <div class="kv"><span class="k">Region</span><span class="v" style="color:var(--red)">🇮🇩 Indonesia</span></div>
      <div class="kv"><span class="k">Created</span><span class="v" style="color:var(--muted)">${new Date(acc.created_at).toLocaleString()}</span></div>
    </div>`;
  cards.prepend(d);
}

async function generateOne(prefix, idx) {
  const r = await fetch(`/api/generate?prefix=${encodeURIComponent(prefix)}`);
  const acc = await r.json();
  stats.total++;
  if (acc.error) {
    stats.err++;
  } else {
    stats.ok++;
    if (['LEGENDARY','EPIC','RARE'].includes(acc.rarity)) stats.rare++;
    allAccounts.push(acc);
  }
  addCard(acc, idx);
  updateStats();
  return acc;
}

async function generate() {
  const prefix = document.getElementById('prefix').value.trim() || 'ANGEL';
  const count  = Math.min(20, Math.max(1, parseInt(document.getElementById('count').value) || 5));
  const btn    = document.getElementById('genBtn');
  const dlBtn  = document.getElementById('dlBtn');

  btn.disabled = true;
  dlBtn.style.display = 'none';
  document.getElementById('cards').innerHTML = '';
  allAccounts = [];
  stats = { total:0, ok:0, err:0, rare:0 };
  updateStats();

  for (let i = 1; i <= count; i++) {
    setStatus(`<span class="spinner"></span> Generating ${i}/${count}...`);
    await generateOne(prefix, i);
    if (i < count) await new Promise(r => setTimeout(r, 400));
  }

  setStatus(`Done — ${stats.ok} generated, ${stats.err} failed`, stats.err > 0 ? 'err' : 'ok');
  btn.disabled = false;
  if (allAccounts.length > 0) dlBtn.style.display = 'block';
}

function downloadJSON() {
  const blob = new Blob([JSON.stringify(allAccounts, null, 2)], {type:'application/json'});
  const a    = document.createElement('a');
  a.href     = URL.createObjectURL(blob);
  a.download = `ff_guest_${Date.now()}.json`;
  a.click();
}
</script>
</body>
</html>"""

# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/", methods=["GET"])
def index():
    return Response(HTML, mimetype="text/html")

@app.route("/api/generate", methods=["GET"])
def api_generate():
    if not _DEPS_OK:
        return jsonify({"error": f"Missing deps: {_DEPS_ERR}"}), 500
    prefix = request.args.get("prefix", "ANGEL")[:10]
    result = generate_one(prefix)
    return jsonify(result)

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({
        "status": "alive",
        "deps":   _DEPS_OK,
        "region": REGION,
        "ts":     datetime.now(timezone.utc).isoformat(),
    })

# Vercel calls `app` directly — no app.run() needed
